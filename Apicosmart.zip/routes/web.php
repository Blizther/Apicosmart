<?php

use App\Http\Controllers\DispositivoFabricadoController;
use App\Http\Controllers\DispositivoWebController;
use App\Http\Controllers\VentaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ControllerApiario;
use App\Http\Controllers\ControllerColmena;
use App\Http\Controllers\ControllerProducto;
use App\Http\Controllers\ControllerVentaUsuario;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ControllerInspeccionColmena;

Route::get('/', function () {
    return view('welcome');
});
//Route::get('/', function () {
//    return view('auth.login');
//});
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');



// creando rutas protegidas por rol
// Rutas para administrador
Route::middleware(['auth', 'rol:administrador'])->group(function () {
    Route::get('/administrador/inicio', function () {
        return view('administrador.inicio');
    });
    Route::resource('users', UserController::class);
    Route::get('/administrador/dispositivos-fabricados',       [DispositivoFabricadoController::class, 'index'])->name('fabricados.index');
    Route::get('/administrador/dispositivos-fabricados/crear', [DispositivoFabricadoController::class, 'create'])->name('fabricados.create');
    Route::post('/administrador/dispositivos-fabricados',      [DispositivoFabricadoController::class, 'store'])->name('fabricados.store');

});

// Rutas para usuario común
Route::middleware(['auth', 'rol:usuario'])->group(function () {
    Route::get('/usuario/inicio', function () {
        return view('usuario.dashboard');
    });
    Route::get('/productos', [ControllerProducto::class, 'metodoProductos']);
    // Mostrar formulario de creación
    Route::get('/productos/crearproducto', [ControllerProducto::class, 'nuevoproducto']);
    // Guardar nuevo producto - es post no get
    Route::post('/productos/guardarproducto', [ControllerProducto::class, 'nuevoproductobd'])->middleware('auth');
    //Route::post('/productos/guardarproducto', [ControllerProducto::class, 'nuevoproductobd']); MODIFICADO
    //Ruta para eliminado (enviando id por direccion url)
    Route::delete('/productos/eliminarproducto/{id}', [ControllerProducto::class, 'eliminarproductobd'])->name('productos.destroy');
    // Mostrar formulario de edición (es get por que muestra formulario de edición)
    Route::get('/productos/{id}/editarproducto', [ControllerProducto::class, 'editarProducto'])->name('productos.editar');
    // Actualizar producto (se utiliza el metodo put)
    Route::put('/productos/editarproducto/{id}', [ControllerProducto::class, 'actualizarProducto'])->name('productos.actualizar');

    //SECCION APIARIO
    Route::get('/apiario', [ControllerApiario::class, 'index'])->name('apiario.index');
    // Mostrar formulario de creación
    Route::get('/apiario/crearapiario', [ControllerApiario::class, 'create'])->name('apiario.create');
    // Guardar nuevo producto - es post no get
    Route::post('/apiario/guardarapiario', [ControllerApiario::class, 'store'])->name('apiario.store');
    //Ruta para eliminado (enviando id por direccion url)
    Route::delete('/apiario/eliminarapiario/{id}', [ControllerApiario::class, 'destroy'])->name('apiario.destroy');
    // Mostrar formulario de edición (es get por que muestra formulario de edición)
    Route::get('/apiario/{id}/editarapiario', [ControllerApiario::class, 'edit'])->name('apiario.edit');
    // Actualizar producto (se utiliza el metodo put)
    Route::put('/apiario/editarapiario/{id}', [ControllerApiario::class, 'update'])->name('apiario.update');

    //SECCION COLMENA
    Route::resource('/colmenas', ControllerColmena::class);
    Route::get('/colmenas/{id}/verInspeccion', [ControllerColmena::class, 'verinspeccion'])->name('colmenas.verinspeccion');
    Route::get('/colmenas/{id}/agregarinspeccion', [ControllerColmena::class, 'agregarinspeccion'])->name('colmenas.agregarinspeccion');
    Route::post('/colmenas/guardarinspeccion', [ControllerInspeccionColmena::class, 'store'])->name('inspeccion.store');
    Route::get('/colmenas/{id}/editar', [ControllerColmena::class, 'edit'])->name('colmenas.edit');  
    Route::get('/colmenas/{id}/guardarcolmena', [ControllerColmena::class, 'update'])->name('colmenas.update'); 


    // Vista de venta del usuario (listado de sus productos + carrito)
    Route::get('/ventaUsuario', [ControllerVentaUsuario::class, 'metodoVentaUsuario'])->name('venta.usuario');

    // Vista principal de ventas (solo mis productos + mi carrito)
    Route::get('/ventaUsuario', [ControllerVentaUsuario::class, 'metodoVentaUsuario'])
        ->name('venta.usuario');

    // Carrito
    Route::post('/ventaUsuario/cart/add',    [VentaController::class, 'cartAdd'])->name('venta.cart.add');
    Route::post('/ventaUsuario/cart/update', [VentaController::class, 'cartUpdate'])->name('venta.cart.update');
    Route::post('/ventaUsuario/cart/remove', [VentaController::class, 'cartRemove'])->name('venta.cart.remove');

    // Checkout
    Route::post('/ventaUsuario/checkout',    [VentaController::class, 'store'])->name('venta.checkout');
    // reportes
     // Lista de reportes
    Route::get('/reporteUsuario', [ControllerVentaUsuario::class, 'metodoReporteUsuario'])
        ->name('venta.reporte');              // <-- ESTE name

    // Detalle de venta
    Route::get('/reporteUsuario/{venta}', [ControllerVentaUsuario::class, 'mostrarVenta'])
        ->whereNumber('venta')
        ->name('venta.reporte.detalle');
    
    Route::get('/ventaUsuario', [ControllerVentaUsuario::class, 'metodoVentaUsuario']);
    Route::get('/reporteUsuario', [ControllerVentaUsuario::class, 'metodoReporteUsuario']);
    Route::get('/stockUsuario', [ControllerVentaUsuario::class, 'metodoStockUsuario']);


    Route::get('/mis/dispositivos', [DispositivoWebController::class, 'index'])->name('mis.dispositivos');
    Route::post('/mis/dispositivos', [DispositivoWebController::class, 'store'])->name('mis.dispositivos.store');
    Route::get('/mis/dispositivos/{id}', [DispositivoWebController::class, 'show'])->name('mis.dispositivos.show');

});
