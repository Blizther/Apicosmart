<?php $__env->startSection('content'); ?>

<div class="container-fluid pt-4 px-4">
  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul style="margin:0;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  <?php if(session('ok')): ?>
    <div class="alert alert-success"><?php echo e(session('ok')); ?></div>
  <?php endif; ?>

  <div class="row g-4">
    
    <div class="col-lg-7">
      <div class="bg-light rounded p-3">
        <h5>Mis productos</h5>
        <div class="table-responsive">
          <table class="table table-sm">
            <thead>
              <tr>
                <th>Imagen</th>
                <th>Descripción</th>
                <th>UM</th>
                <th>Stock</th>
                <th>Precio</th>
                <th style="width:220px;">Agregar</th>
              </tr>
            </thead>
            <tbody>
              <?php ($i=1); ?>
              <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td>
                    <?php if($p->imagen): ?>
                      <img src="<?php echo e(asset($p->imagen)); ?>"
                           alt="<?php echo e($p->descripcion); ?>"
                           style="width:60px; height:60px; object-fit:cover; border-radius:6px;">
                    <?php else: ?>
                      <img src="<?php echo e(asset('images/no-image.png')); ?>"
                           alt="Sin imagen"
                           style="width:60px; height:60px; object-fit:cover; border-radius:6px;">
                    <?php endif; ?>
                  </td>
                  <td><?php echo e($p->descripcion); ?></td>
                  <td><?php echo e($p->unidadMedida); ?></td>
                  <td><?php echo e($p->stock); ?></td>
                  <td><?php echo e(number_format($p->precio,2)); ?></td>
                  <td>
                    <form method="POST" action="<?php echo e(route('venta.cart.add')); ?>" class="d-inline-flex align-items-center" style="gap:8px;">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="producto_id" value="<?php echo e($p->id); ?>">
                      <input type="number" class="form-control form-control-sm" name="cantidad" min="1" value="1" style="width:90px;">
                      <button type="submit" class="btn btn-primary btn-sm">Agregar</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">No tienes productos registrados.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    
    <div class="col-lg-5">
      <div class="bg-light rounded p-3">
        <h5>Mi carrito</h5>
        <div class="table-responsive">
          <table class="table table-sm">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cant.</th>
                <th>Unit.</th>
                <th>Subt.</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php ($sub = $item['precio'] * $item['cantidad']); ?>
                <tr>
                  <td><?php echo e($item['descripcion']); ?></td>
                  <td>
                    <form method="POST" action="<?php echo e(route('venta.cart.update')); ?>" class="d-inline-flex align-items-center" style="gap:6px;">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="producto_id" value="<?php echo e($item['id']); ?>">
                      <input type="number" name="cantidad" min="1" value="<?php echo e($item['cantidad']); ?>" class="form-control form-control-sm" style="width:80px;">
                      <button class="btn btn-secondary btn-sm" type="submit">OK</button>
                    </form>
                  </td>
                  <td><?php echo e(number_format($item['precio'],2)); ?></td>
                  <td><?php echo e(number_format($sub,2)); ?></td>
                  <td>
                    <form method="POST" action="<?php echo e(route('venta.cart.remove')); ?>">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="producto_id" value="<?php echo e($item['id']); ?>">
                      <button class="btn btn-danger btn-sm" type="submit">Quitar</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">Tu carrito está vacío.</td></tr>
              <?php endif; ?>
            </tbody>
            <tfoot>
              <tr>
                <th colspan="3" class="text-end">Total:</th>
                <th><?php echo e(number_format($total,2)); ?></th>
                <th></th>
              </tr>
            </tfoot>
          </table>
        </div>

        
        <form method="POST" action="<?php echo e(route('venta.checkout')); ?>" class="mt-2">
          <?php echo csrf_field(); ?>
          <div class="mb-2">
            <label>Cliente</label>
            <input type="text" name="cliente_nombre" class="form-control form-control-sm" value="<?php echo e(old('cliente_nombre')); ?>">
          </div>
          <div class="mb-2">
            <label>Documento</label>
            <input type="text" name="cliente_doc" class="form-control form-control-sm" value="<?php echo e(old('cliente_doc')); ?>">
          </div>
          <div class="mb-3">
            <label>Método de pago</label>
            <select name="metodo_pago" class="form-control form-control-sm">
              <option value="efectivo">Efectivo</option>
              <option value="qr">QR</option>
              <option value="tarjeta">Tarjeta</option>
            </select>
          </div>
          <button class="btn btn-success btn-sm" type="submit" <?php if(empty($cart)): ?> disabled <?php endif; ?>>Confirmar venta</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/ventaUsuario/ventaUsuario.blade.php ENDPATH**/ ?>