

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
  <h3>Inventario de Dispositivos Fabricados</h3>

  <?php if(session('ok')): ?>
  <div class="alert alert-success mt-3">
    <?php echo e(session('ok')); ?><br>
    <?php if(session('api_key')): ?>
    <strong>API-KEY (copiar ahora, no se mostrará de nuevo):</strong>
    <code><?php echo e(session('api_key')); ?></code>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <div class="my-3">
    <a href="<?php echo e(route('fabricados.create')); ?>" class="btn btn-success">Nuevo dispositivo</a>
  </div>

  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Serial</th>
        <th>API-KEY</th> 
        <th>Estado</th>
        <th>Creado</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><?php echo e($it->id); ?></td>
        <td><code><?php echo e($it->serial); ?></code></td>
        <td>
          <?php if($it->api_key_hash): ?>
          <code><?php echo e($it->api_key_hash); ?></code>
          <?php else: ?>
          <span class="text-muted">—</span>
          <?php endif; ?>
        </td>

        <td><?php echo e($it->estado ? 'Activo' : 'Inactivo'); ?></td>
        <td><?php echo e($it->created_at); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
        <td colspan="5" class="text-center">Sin registros</td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>


  <?php echo e($items->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrador.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/dispositivos_fabricados/index.blade.php ENDPATH**/ ?>