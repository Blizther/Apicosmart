

<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <h3 class="mb-4">Registrar nuevo dispositivo fabricado</h3>

    
    <?php if(session('ok')): ?>
        <div class="alert alert-success">
            <?php echo e(session('ok')); ?>

            <?php if(session('api_key')): ?>
                <div class="mt-2">
                    <strong>API-KEY generada:</strong>
                    <code><?php echo e(session('api_key')); ?></code><br>
                    <small class="text-muted">Guárdala en un lugar seguro. No se volverá a mostrar.</small>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('fabricados.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="serial" class="form-label fw-bold">Serial del dispositivo</label>
                    <input 
                        type="text" 
                        id="serial" 
                        name="serial" 
                        class="form-control text-uppercase" 
                        placeholder="Ej: ABCD-ASER4-45AL-12PL" 
                        value="<?php echo e(old('serial')); ?>" 
                        required 
                        oninput="this.value=this.value.toUpperCase().trim()">
                    <?php $__errorArgs = ['serial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="<?php echo e(route('fabricados.index')); ?>" class="btn btn-secondary">Volver</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/dispositivos_fabricados/create.blade.php ENDPATH**/ ?>