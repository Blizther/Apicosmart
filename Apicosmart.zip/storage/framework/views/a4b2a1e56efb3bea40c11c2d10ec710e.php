<?php $__env->startSection('content'); ?>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">

    <div class="row g-4">
        <div class="col-sm-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('successdelete')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('successdelete')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('successedit')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('successedit')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="mb-3">
        <a href="<?php echo e(route('colmenas.create')); ?>" class="btn btn-success">
            <i class="fa fa-plus"></i> Agregar colmena
        </a>
    </div>


    <div class="row g-4">
        <div class="col-sm-12">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <h1>Panel de colmenas</h1>
            </div>
        </div>

        <div class="col-sm-12">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">NRO</th>
                            <th scope="col">Código</th>
                            <th scope="col">Nombre de Apiario</th>
                            <th scope="col">Fecha Fabricación</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Cantidad de Marcos</th>
                            <th scope="col">Modelo</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $correlativo=1;
                        ?>
                        <?php $__currentLoopData = $colmenas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colmena): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo $correlativo; ?></th>
                                <td><?php echo e($colmena->codigo); ?></td>
                                <td><?php echo e($colmena->apiario->nombre); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($colmena->fechaFabricacion)->format('d/m/Y H:i:s')); ?></td>
                                <td><?php echo e($colmena->estado); ?></td>
                                <td><?php echo e($colmena->cantidadMarco); ?></td>
                                <td><?php echo e($colmena->modelo); ?></td>
                                
                                <td>
                                    <a href="<?php echo e(route('colmenas.verinspeccion', $colmena->idColmena)); ?>" class="btn btn-primary btn-sm">Ver Inspecciones</a>
                                    <a href="<?php echo e(route('colmenas.edit', $colmena->idColmena)); ?>" class="btn btn-warning btn-sm">Editar</a>
                                    <!-- Botón Eliminar -->
                                    <form action="<?php echo e(route('colmenas.destroy', $colmena->idColmena)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('¿Estás seguro de que deseas eliminar esta colmena?')">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                        $correlativo++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/colmena/index.blade.php ENDPATH**/ ?>