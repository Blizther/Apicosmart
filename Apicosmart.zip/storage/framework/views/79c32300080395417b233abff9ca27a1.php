<?php $__env->startSection('content'); ?>
<p>estoy en el  panel de Stock Usuario</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/ventaUsuario/stockUsuario.blade.php ENDPATH**/ ?>