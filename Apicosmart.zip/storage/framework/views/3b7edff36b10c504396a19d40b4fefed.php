<?php $__env->startSection('content'); ?>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">

    <div class="row g-4">
        <div class="col-sm-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('successdelete')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('successdelete')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('successedit')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('successedit')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-sm-12">
            <a href="<?php echo asset(''); ?>productos/crearproducto">
                <button type="submit" class="btn btn-success">AGREGAR PRODUCTO</button>
            </a>
        </div>
    </div>


    <div class="row g-4">
        <div class="col-sm-12">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <h1>Panel de ventas</h1>
            </div>
        </div>

        <div class="col-sm-12">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Descripcion</th>
                            <th scope="col">Unidad de Medida</th>
                            <th scope="col">Stock</th>
                            <th scope="col">Precio</th>
                            <th scope="col">Imagen</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $correlativo=1;
                        ?>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo $correlativo; ?></th>
                                <td><?php echo e($producto->descripcion); ?></td>
                                <td><?php echo e($producto->unidadMedida); ?></td>
                                <td><?php echo e($producto->stock); ?></td>
                                <td><?php echo e($producto->precio); ?></td>
                                <td>
                                    <?php if($producto->imagen): ?>
                                        <img src="<?php echo e(asset($producto->imagen)); ?>" alt="Imagen Actual" width="100"><br><br>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Botón Eliminar -->
                                    <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('¿Estás seguro de que deseas eliminar este producto?')">
                                            Eliminar
                                        </button>
                                    </form>

                                    <a href="<?php echo e(route('productos.editar', $producto->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                                </td>
                            </tr>
                        <?php
                        $correlativo++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/productos/productos.blade.php ENDPATH**/ ?>