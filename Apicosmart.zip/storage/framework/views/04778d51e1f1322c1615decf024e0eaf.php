

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
  <h3>Lecturas del dispositivo</h3>
  <p class="text-muted mb-2">
    Serial: <code><?php echo e($dispositivo->fabricado->serial ?? '—'); ?></code> |
    Nombre: <?php echo e($dispositivo->nombre ?? '—'); ?>

  </p>

  <div class="card">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-sm">
          <thead>
            <tr>
              <th>ID</th>
              <th>Fecha/Hora</th>
              <th>Temperatura (°C)</th>
              <th>Humedad (%)</th>
              <th>Peso (kg)</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $lecturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($l->id); ?></td>
                <td><?php echo e($l->ts ?? $l->created_at); ?></td>
                <td><?php echo e($l->temperatura); ?></td>
                <td><?php echo e($l->humedad); ?></td>
                <td><?php echo e($l->peso); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="5" class="text-center text-muted">Sin lecturas registradas.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php echo e($lecturas->links()); ?>

    </div>
  </div>

  <div class="mt-3">
    <a href="<?php echo e(route('mis.dispositivos')); ?>" class="btn btn-secondary">Volver</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/dispositivos/show.blade.php ENDPATH**/ ?>