<?php $__env->startSection('content'); ?>

<div class="container-fluid pt-4 px-4">

    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul style="margin:0;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('ok')): ?>
    <div class="alert alert-success"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>

    
    <div class="bg-light rounded p-3 mb-3">
        <h5 class="mb-3">Reporte de ventas</h5>
        <form method="GET" action="<?php echo e(url()->current()); ?>" class="row g-3">
            <div class="col-sm-3">
                <label class="form-label">Desde</label>
                <input type="date" name="from" value="<?php echo e($from); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-sm-3">
                <label class="form-label">Hasta</label>
                <input type="date" name="to" value="<?php echo e($to); ?>" class="form-control form-control-sm">
            </div>
            <div class="col-sm-3 d-flex align-items-end">
                <button class="btn btn-primary btn-sm" type="submit">Aplicar filtros</button>
            </div>
            <div class="col-sm-3 d-flex align-items-end">
                <a href="<?php echo e(url()->current()); ?>" class="btn btn-outline-secondary btn-sm">Limpiar</a>
            </div>
        </form>
    </div>

    
    <div class="row g-3 mb-3">
        <div class="col-md-4">
            <div class="bg-light rounded p-3">
                <div class="d-flex justify-content-between">
                    <span>Ventas</span>
                    <strong><?php echo e(number_format($resumen['cantidadVentas'])); ?></strong>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-light rounded p-3">
                <div class="d-flex justify-content-between">
                    <span>Total vendido</span>
                    <strong>Bs. <?php echo e(number_format($resumen['totalVendido'], 2)); ?></strong>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-light rounded p-3">
                <div class="d-flex justify-content-between">
                    <span>Ítems vendidos</span>
                    <strong><?php echo e(number_format($resumen['itemsVendidos'])); ?></strong>
                </div>
            </div>
        </div>
    </div>

    
    <div class="bg-light rounded p-3">
        <div class="table-responsive">
            <table class="table table-sm align-middle">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Fecha</th>
                        <th class="text-end">Total (Bs.)</th>
                        <th class="text-center">Estado</th>
                        <th class="text-end">Ítems</th>
                        <th class="text-center">Acciones</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                    $itemsCount = $v->detalles?->sum('cantidad') ?? 0;
                    $badge = ($v->estado == 1) ? 'success' : 'secondary';
                    $estadoTxt = ($v->estado == 1) ? 'Confirmada' : 'Anulada';
                    ?>
                    <tr>
                        <td><?php echo e($v->id); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($v->fecha)->format('Y-m-d H:i')); ?></td>
                        <td class="text-end"><?php echo e(number_format($v->total, 2)); ?></td>
                        <td class="text-center">
                            <span class="badge bg-<?php echo e($badge); ?>"><?php echo e($estadoTxt); ?></span>
                        </td>
                        <td class="text-end"><?php echo e($itemsCount); ?></td>
                        <td class="text-center">
                            <a class="btn btn-outline-primary btn-sm"
                                href="<?php echo e(route('venta.reporte.detalle', $v->id)); ?>">
                                Ver detalle
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">No hay ventas en el período seleccionado.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuario.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/ventaUsuario/reporteUsuario.blade.php ENDPATH**/ ?>