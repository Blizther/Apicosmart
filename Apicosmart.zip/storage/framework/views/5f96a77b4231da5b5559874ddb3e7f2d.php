<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <?php if(auth()->user()->role === 'administrador'): ?>
        <a href="<?php echo e(route('administrador.inicio')); ?>" class="btn btn-secondary mb-3">← Volver al Inicio</a>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Lista de Usuarios</h2>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">+ Crear nuevo usuario</a>
    </div>

    
    <form method="GET" action="<?php echo e(route('users.index')); ?>" class="mb-3 d-flex" role="search">
        <input type="text"
               name="q"
               class="form-control me-2"
               placeholder="Buscar por nombre, apellidos o email…"
               value="<?php echo e($q ?? request('q')); ?>">
        <button type="submit" class="btn btn-outline-secondary">Buscar</button>

        <?php if(!empty($q)): ?>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-link ms-2">Limpiar</a>
        <?php endif; ?>
    </form>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card shadow">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido Paterno</th>
                            <th>Apellido Materno</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($user->nombre); ?></td>
                                <td><?php echo e($user->primerApellido); ?></td>
                                <td><?php echo e($user->segundoApellido); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><span class="badge bg-info text-dark"><?php echo e(ucfirst($user->rol)); ?></span></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-sm btn-warning">Editar</a>
                                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"
                                            onclick="return confirm('¿Eliminar usuario?')">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">
                                    <?php if(!empty($q)): ?>
                                        No se encontraron resultados para “<?php echo e($q); ?>”.
                                    <?php else: ?>
                                        No hay usuarios registrados.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <?php if(method_exists($users, 'links')): ?>
                <div class="mt-2">
                    <?php echo e($users->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrador.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Apicosmart\resources\views/users/index.blade.php ENDPATH**/ ?>