@extends('usuario.inicio')
@section('content')
<p>estoy en el  panel de Stock Usuario</p>

@endsection